module.exports = {
  port: 8088,
  root: "./",
  open: ["index.html"],
  host: "0.0.0.0",
  browser: "chrome",
  https: false,
};
