let name = "john";
console.log(`Hello ${name}!!`);
